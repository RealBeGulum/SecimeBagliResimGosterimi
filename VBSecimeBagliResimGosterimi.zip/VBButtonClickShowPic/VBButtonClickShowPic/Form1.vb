﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If Not CheckBox1.Checked Then
            BufImage1 = Nothing
            BufImage2 = Nothing
        End If
    End Sub

    Dim BufImage1 As Image
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If CheckBox1.Checked Then
            If BufImage1 Is Nothing Then
                Dim FD As New OpenFileDialog
                FD.FileName = "Resim1"
                FD.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.Desktop
                FD.Filter = "JPG|*.jpg|JPEG|*.jpeg|PNG|*.png|GIF|*.gif"
                If FD.ShowDialog() = DialogResult.OK Then
                    BufImage1 = Image.FromFile(FD.FileName)
                    PictureBox1.Image = BufImage1
                End If
            Else
                PictureBox1.Image = BufImage1
            End If
        Else
            PictureBox1.Image = My.Resources.Cristal_006
        End If
    End Sub

    Dim BufImage2 As Image
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If CheckBox1.Checked Then
            If BufImage2 Is Nothing Then
                Dim FD As New OpenFileDialog
                FD.FileName = "Resim2"
                FD.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.Desktop
                FD.Filter = "JPG|*.jpg|JPEG|*.jpeg|PNG|*.png|GIF|*.gif"
                If FD.ShowDialog() = DialogResult.OK Then
                    BufImage2 = Image.FromFile(FD.FileName)
                    PictureBox1.Image = BufImage2
                End If
            Else
                PictureBox1.Image = BufImage2
            End If
        Else
            PictureBox1.Image = My.Resources.Cristal_008
        End If
    End Sub

End Class
