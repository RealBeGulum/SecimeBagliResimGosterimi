﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CsharpButtonClickShowPic
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void CheckBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            if (!CheckBox1.Checked)
            {
                BufImage1 = null;
                BufImage2 = null;
            }
        }

        private Image BufImage1;
        private void Button1_Click_1(object sender, EventArgs e)
        {
            if (CheckBox1.Checked)
            {
                if (BufImage1 == null)
                {
                    OpenFileDialog FD = new OpenFileDialog();
                    FD.FileName = "Resim1";
                    FD.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                    FD.Filter = "JPG|*.jpg|JPEG|*.jpeg|PNG|*.png|GIF|*.gif";
                    if (FD.ShowDialog() == DialogResult.OK)
                    {
                        BufImage1 = Image.FromFile(FD.FileName);
                        PictureBox1.Image = BufImage1;
                    }
                }
                else
                    PictureBox1.Image = BufImage1;
            }
            else
                PictureBox1.Image = Properties.Resources.Cristal_006;
        }

        private Image BufImage2;
        private void Button2_Click(object sender, EventArgs e)
        {
            if (CheckBox1.Checked)
            {
                if (BufImage2 == null)
                {
                    OpenFileDialog FD = new OpenFileDialog();
                    FD.FileName = "Resim2";
                    FD.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                    FD.Filter = "JPG|*.jpg|JPEG|*.jpeg|PNG|*.png|GIF|*.gif";
                    if (FD.ShowDialog() == DialogResult.OK)
                    {
                        BufImage2 = Image.FromFile(FD.FileName);
                        PictureBox1.Image = BufImage2;
                    }
                }
                else
                    PictureBox1.Image = BufImage2;
            }
            else
                PictureBox1.Image = Properties.Resources.Cristal_008;
        }
    }
}

